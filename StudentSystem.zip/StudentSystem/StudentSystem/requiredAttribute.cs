﻿using System;

namespace StudentSystem
{
    internal class requiredAttribute : Attribute
    {
    }
}