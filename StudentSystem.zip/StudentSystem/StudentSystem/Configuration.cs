﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentSystem
{
    public static class Configuration
    {
        public static string ConfigurationString = @"Server=.;Database = StudentSystemDB ; Trusted_Connection=True";
    }
}
